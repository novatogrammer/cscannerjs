import { split, trim, matched, tabular } from './String.mjs';
import { Token } from './Token.mjs';

const SIMBOLS = {
  TRIPLE: ['>>=', '<<='],
  DOUBLE: ['==', '!=', '>=', '<=', '>>', '<<', '&&', '||', '//', '->', '++', '--', '+=', '-=', '*=', '/=', '%=', '&=', '|=', '^='],
  SINGLE: ['.', ',', ';', ':', '#', '<', '>', '*', '+', '-', '=', '&', '|', '^', '~', '!', '%', '?', '"', '\'', '/'],
  OPEN_CLOSE: ['(', ')', '{', '}', '<', '>', '[', ']'],
  STRINGS: ['\"', '\''],
  ESCAPE: ['\n', '\t', '\r', '\0', '\\', '\v', '\f']
};

export class Scanner {

  constructor({ endLine = '\n', separator = ' ', spaces = true }) {
    this.spaces = spaces;
    this.content = "";
    this.contentSplit = [];
    this.contentTrim = [];
    this.endLine = endLine;
    this.lines = [];
    this.separator = separator;
    this.sections = [];
    this.chars = [];
    this.tokens = [];
  }

  read(content) {

    this.content = content;
    this.contentSplit = split(content, ' ');
    this.contentTrim = trim(content);
    this.lines = split(trim(content), this.endLine, true);

    this.lines.forEach((line) => {
      if (line.includes('\"') || line.includes('\'')) {
        let lineSections = split(line, this.separator, true);
        let isString = -1;
        let sections = [];
        lineSections.forEach((section, i) => {
          if (section.includes('"') || section.includes('\'')) {
            if (isString == -1) {
              isString = i;
              sections.push(section);
            }
            else {
              sections[isString] = sections[isString] + section;
              isString = -1;
            }
          }
          else {
            if (isString == -1) {
              sections.push(section);
            }
            else {
              sections[isString] = sections[isString] + section;
            }
          }
        });
        this.sections.push(sections);
      }
      else {
        this.sections.push(line.split(this.separator));
      }
    });

    this.sections.forEach((section) => {
      section.forEach((group) => {
        this.chars.push(group.split(''));
      });
    });

    this.chars.forEach((chars, index) => {
      let token = "";
      let isString = false;

      chars.forEach((char, i) => {

        if(token != '') {
          if (SIMBOLS.DOUBLE.indexOf(token) != -1 || SIMBOLS.TRIPLE.indexOf(token) != -1) {
            this.tokens.push(trim(token));
            token = "";
          }
        }

        if(SIMBOLS.STRINGS.indexOf(char) != -1 || isString) {
          if(!isString) {
            if(token != '') {
              this.tokens.push(trim(token));
            }
            token = "";
          }
          if(isString && SIMBOLS.STRINGS.indexOf(char) != -1) {
            token += char;
            this.tokens.push(trim(token));
            token = "";
            isString = false;
          }
          else {
            token += char;
            isString = true;
          }
        }
        else if (!this.isOpenClose(char) 
          && !this.isSingle(char)
          && !this.isTriple(char, index, i)
          && !this.isDouble(char, index, i)
          || (char.toLowerCase() === 'e'
          || chars[i - 1] != undefined
            && (['+', '-'].indexOf(char) != -1
              && chars[i - 1].toLowerCase() === 'e'))) {
          token += char;
          isString = false;
        }
        else if (!this.isOpenClose(char) 
          && !this.isSingle(char)
          || this.isTriple(char, index, i)
          || this.isDouble(char, index, i)) {
            for(let i = 0; i < token.length; i++) {
              const c = token[i];
              if(['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'].indexOf(c.toLowerCase()) != -1) {
                this.tokens.push(trim(token));
                token = "";
                break;
              }
            }
            token += char;
            isString = false;
        }
        else if(this.isOpenClose(char) || this.isSingle(char)) {
          if(token != '' && !this.isSingle(this.chars[index][i-1])) {
            this.tokens.push(trim(token));
          }
          token = "";
          this.tokens.push(char);
          isString = false;
        }
        else {
          if(token != '') {
            this.tokens.push(trim(token));
          }
          token = "";
          this.tokens.push(char);
          isString = false;
        }
        
      });

      this.tokens.push(trim(token));
      token = "";
    });

    console.log(this.tokens);

    let tokens = [];

    this.tokens.forEach(token => {
      matched(token, SIMBOLS.ESCAPE, this.spaces).forEach(nt => {
        tokens.push(nt);
      });
    });

    this.tokens = tabular(tokens);

    return this;
  }

  isOpenClose(char) {
    return SIMBOLS.OPEN_CLOSE.indexOf(char) !== -1;
  }

  isSingle(char) {
    return SIMBOLS.SINGLE.indexOf(char) !== -1;
  }

  isDouble(char, index, i) {
    if(this.chars[index][i + 1] || this.chars[index][i - 1]) {
      return (SIMBOLS.DOUBLE.indexOf(char + this.chars[index][i + 1]) !== -1) || (SIMBOLS.DOUBLE.indexOf(this.chars[index][i - 1] + char) !== -1);
    }
    return false;
  }

  isTriple(char, index, i) {
    if(this.chars[index][i + 1] || this.chars[index][i - 1] || this.chars[index][i + 2] || this.chars[index][i - 2]) {
      return (SIMBOLS.TRIPLE.indexOf(char + this.chars[index][i + 1] + this.chars[index][i + 2] ) !== -1) || (SIMBOLS.TRIPLE.indexOf(this.chars[index][i - 1] + char + this.chars[index][i + 1] ) !== -1) || (SIMBOLS.TRIPLE.indexOf(this.chars[index][i - 1] + this.chars[index][i - 2] + char) !== -1);
    }
    return false;
  }

  getContent() {
    return this.content;
  }

  getLines() {
    return this.lines;
  }

  getSections() {
    return this.sections;
  }

  getChars() {
    return this.chars;
  }

  getTokens() {
    let tokens = [];
    this.tokens.forEach((token) => {
      tokens.push(new Token(token));
    });
    return tokens;
  }

}