const _INPUTS = [
  `int main() {
  int a;
  int b;
  a = b + 1;
  return 0;
}`,
  `void main() {
  int a;
  int b;
  c = 3E+2;
  char* abc = "aksnnasjnajsnjnas asuabshnajds ajsjasdjbas";
  a = b + 122;
  return 0;
  }`,
  `#include <stdio.h>

int main () {
  int opcion = 1;
  string nombre = scanf("Ingrese. un! nombre");
  switch(opcion) {
    case 1:
        printf(nombre != "" ? nombre : "Desconocido"));
        break;
    default:
        printf("Opción no válida");
  }
  return 1 || 0;
}\0`,
`#include <stdio.h>

int main() {
    int opcion;
    float num1, num2, resultado = 0;

    printf("Ingrese el primer número: ");
    scanf("%f", &num1);
    printf("Ingrese el segundo número: ");
    scanf("%f", &num2);

    printf("Seleccione la operación:");
    printf("1. Suma");
    printf("2. Resta");
    printf("3. Multiplicación");
    printf("4. División");
    printf("Opción: ");
    scanf("%d", &opcion);

    switch (opcion) {
        case 1:
            resultado = num1 + num2;
            break;
        case 2:
            resultado = num1 - num2;
            break;
        case 3:
            resultado = num1 * num2;
            break;
        case 4:
            if (num2 != 0) {
              resultado = num1 / num2;
            }
            else {
              printf("No se puede dividir por cero.");
            }
            break;
        default:
            printf("Opción inválida.");
    }

    if (opcion >= 1 && opcion <= 4) {
        printf("El resultado es: %.2f", resultado);

        for (int i = 0; i < 5; i++) {
            if (resultado > 10) {
                resultado -= 5;
            } else {
                resultado += 3;
            }
        }

        printf("El resultado modificado es: %.2f", resultado);
    }

    return 0;
}\0`,
`
#include<ncurses.h>
#include<stdlib.h>

#define ENTER	10
#define ESCAPE	27

void init_curses();
void draw_menubar(WINDOW * menubar);
WINDOW **draw_menu(int start_col);
void delete_menu(WINDOW **items, int count);
int scroll_menu(WINDOW **items, int count, int menu_start_col);


int main(){

	int key;
	WINDOW *menubar, *messagebar;

	init_curses();
	bkgd(COLOR_PAIR(1));
	menubar = subwin(stdscr, 1, 80, 0, 0);
	messagebar = subwin(stdscr, 1, 79, 23, 1 );
	draw_menubar(menubar);
	move(2, 1);
	printw("Press F1 or F2 to open the menus. ");
	printw("ESC quits.");
	refresh();

	do{
		int selected_item;
		WINDOW **menu_items;
		key = getch();
		werase(messagebar);
		if( key == KEY_F(1)){
			menu_items = draw_menu(0);
			selected_item = scroll_menu(menu_items, 8, 0);
			delete_menu(menu_items, 9);
			if(selected_item < 0 )
				wprintw(messagebar, "You haven't selected any item.");
			else
				wprintw(messagebar, "You have selected menu item %d.", selected_item + 1);
			touchwin(stdscr);
			refresh();		
		}else if(key == KEY_F(2)){
			menu_items = draw_menu(20);
			selected_item = scroll_menu(menu_items, 8, 20);
			delete_menu(menu_items, 9);
			if (selected_item < 0)
				wprintw(messagebar, "You haven't selected any item.");
			else
				wprintw(messagebar, "You have selected menu item %d.", selected_item + 1);
			touchwin(stdscr);
			refresh();		
		}	
	}while(key != ESCAPE);

	delwin(menubar);
	delwin(messagebar);
	endwin();
	return 0;
	

	

	getch();
	endwin();
}

void init_curses(){

	initscr();
	start_color();
	init_pair(1, COLOR_WHITE, COLOR_BLUE);
	init_pair(2, COLOR_BLUE, COLOR_WHITE);
	init_pair(3, COLOR_RED, COLOR_WHITE);
	curs_set(0);
	noecho();
	keypad(stdscr, TRUE);
}

void draw_menubar(WINDOW * menubar){
	wbkgd(menubar, COLOR_PAIR(2));
	
	waddstr(menubar, "Menu 1");
	wattron(menubar, COLOR_PAIR(3));
	waddstr(menubar, "(F1)");
	wattroff(menubar, COLOR_PAIR(3));
	
	wmove(menubar, 0, 20);
	
	waddstr(menubar, "Menu 2");
	wattron(menubar, COLOR_PAIR(3));
	waddstr(menubar, "(F2)");
	wattroff(menubar, COLOR_PAIR(3));
}
WINDOW **draw_menu(int start_col){
	int i;
	WINDOW **items;
	items=(WINDOW ** ) malloc(9 * sizeof(WINDOW *));

	items[0]=newwin(10, 19, 1, start_col);
	wbkgd(items[0], COLOR_PAIR(2));
	box(items[0], ACS_VLINE, ACS_HLINE);
	items[1] = subwin(items[0], 1, 17, 2, start_col+1);
	items[2] = subwin(items[0], 1, 17, 3, start_col+1);
	items[3] = subwin(items[0], 1, 17, 4, start_col+1);
	items[4] = subwin(items[0], 1, 17, 5, start_col+1);
	items[5] = subwin(items[0], 1, 17, 6, start_col+1);
	items[6] = subwin(items[0], 1, 17, 7, start_col+1);
	items[7] = subwin(items[0], 1, 17, 8, start_col+1);
	items[8] = subwin(items[0], 1, 17, 9, start_col+1);
	for(i = 1; i < 9; i++)
		wprintw(items[i], "Item%d", i);
	wbkgd(items[1], COLOR_PAIR(1));
	wrefresh(items[0]);
	return items;
}
void delete_menu(WINDOW **items, int count){
	int i;
	for(i=0; i < count; i++)
		delwin(items[i]);
	free(items);
}
int scroll_menu(WINDOW **items, int count, int menu_start_col){
	int key;
	int selected = 0;
	while(1){
		key=getch();
		if(key == KEY_DOWN || key == KEY_UP){
			wbkgd(items[selected+1], COLOR_PAIR(2));
			wnoutrefresh(items[selected+1]);
			if(key == KEY_DOWN){
				selected = (selected+1) % count;
			} else{
				selected = (selected + count - 1) % count;
			}
			wbkgd(items[selected+1], COLOR_PAIR(1));
			wnoutrefresh(items[selected+1]);
			doupdate();
		} else if ( key == KEY_LEFT || key == KEY_RIGHT){
			delete_menu(items, count + 1 );
			touchwin(stdscr);
			refresh();
			items = draw_menu(20-menu_start_col);
			return scroll_menu(items, 8, 20-menu_start_col);
		} else if(key == ESCAPE){
			return -1;
		} else if(key == ENTER ){
			return selected;
		}
	}	
}
`,
`
#define LUA_BITOP_VERSION	"1.0.2"

#define LUA_LIB
#include "lua.h"
#include "lauxlib.h"

#include "bit.h"

#ifdef _MSC_VER
typedef __int32 int32_t;
typedef unsigned __int32 uint32_t;
typedef unsigned __int64 uint64_t;
#else
#include <stdint.h>
#endif

typedef int32_t SBits;
typedef uint32_t UBits;

typedef union {
  lua_Number n;
#ifdef LUA_NUMBER_DOUBLE
  uint64_t b;
#else
  UBits b;
#endif
} BitNum;

static UBits barg(lua_State *L, int idx)
{
  BitNum bn;
  UBits b;
#if LUA_VERSION_NUM < 502
  bn.n = lua_tonumber(L, idx);
#else
  bn.n = luaL_checknumber(L, idx);
#endif
#if defined(LUA_NUMBER_DOUBLE)
  bn.n += 6755399441055744;
#ifdef SWAPPED_DOUBLE
  b = (UBits)(bn.b >> 32);
#else
  b = (UBits)bn.b;
#endif
#elif defined(LUA_NUMBER_INT) || defined(LUA_NUMBER_LONG) || \
      defined(LUA_NUMBER_LONGLONG) || defined(LUA_NUMBER_LONG_LONG) || \
      defined(LUA_NUMBER_LLONG)
  if (sizeof(UBits) == sizeof(lua_Number))
    b = bn.b;
  else
    b = (UBits)(SBits)bn.n;
#elif defined(LUA_NUMBER_FLOAT)
#error "A 'float' lua_Number type is incompatible with this library"
#else
#error "Unknown number type, check LUA_NUMBER_* in luaconf.h"
#endif
#if LUA_VERSION_NUM < 502
  if (b == 0 && !lua_isnumber(L, idx)) {
    luaL_typerror(L, idx, "number");
  }
#endif
  return b;
}

#define BRET(b)  lua_pushnumber(L, (lua_Number)(SBits)(b)); return 1;

static int bit_tobit(lua_State *L) { BRET(barg(L, 1)) }
static int bit_bnot(lua_State *L) { BRET(~barg(L, 1)) }

#define BIT_OP(func, opr) \
  static int func(lua_State *L) { int i; UBits b = barg(L, 1); \
    for (i = lua_gettop(L); i > 1; i--) b opr barg(L, i); BRET(b) }
BIT_OP(bit_band, &=)
BIT_OP(bit_bor, |=)
BIT_OP(bit_bxor, ^=)

#define bshl(b, n)  (b << n)
#define bshr(b, n)  (b >> n)
#define bsar(b, n)  ((SBits)b >> n)
#define brol(b, n)  ((b << n) | (b >> (32-n)))
#define bror(b, n)  ((b << (32-n)) | (b >> n))
#define BIT_SH(func, fn) \
  static int func(lua_State *L) { \
    UBits b = barg(L, 1); UBits n = barg(L, 2) & 31; BRET(fn(b, n)) }
BIT_SH(bit_lshift, bshl)
BIT_SH(bit_rshift, bshr)
BIT_SH(bit_arshift, bsar)
BIT_SH(bit_rol, brol)
BIT_SH(bit_ror, bror)

static int bit_bswap(lua_State *L)
{
  UBits b = barg(L, 1);
  b = (b >> 24) | ((b >> 8) & 0xff00) | ((b & 0xff00) << 8) | (b << 24);
  BRET(b)
}

static int bit_tohex(lua_State *L)
{
  UBits b = barg(L, 1);
  SBits n = lua_isnone(L, 2) ? 8 : (SBits)barg(L, 2);
  const char *hexdigits = "0123456789abcdef";
  char buf[8];
  int i;
  if (n < 0) { n = -n; hexdigits = "0123456789ABCDEF"; }
  if (n > 8) n = 8;
  for (i = (int)n; --i >= 0; ) { buf[i] = hexdigits[b & 15]; b >>= 4; }
  lua_pushlstring(L, buf, (size_t)n);
  return 1;
}

static const struct luaL_Reg bit_funcs[] = {
  { "tobit",	bit_tobit },
  { "bnot",	bit_bnot },
  { "band",	bit_band },
  { "bor",	bit_bor },
  { "bxor",	bit_bxor },
  { "lshift",	bit_lshift },
  { "rshift",	bit_rshift },
  { "arshift",	bit_arshift },
  { "rol",	bit_rol },
  { "ror",	bit_ror },
  { "bswap",	bit_bswap },
  { "tohex",	bit_tohex },
  { NULL, NULL }
};

#define BAD_SAR		(bsar(-8, 2) != (SBits)-2)

LUALIB_API int luaopen_bit(lua_State *L)
{
  UBits b;
  lua_pushnumber(L, (lua_Number)1437217655L);
  b = barg(L, -1);
  if (b != (UBits)1437217655L || BAD_SAR) {
    const char *msg = "compiled with incompatible luaconf.h";
#ifdef LUA_NUMBER_DOUBLE
#ifdef _WIN32
    if (b == (UBits)1610612736L)
      msg = "use D3DCREATE_FPU_PRESERVE with DirectX";
#endif
    if (b == (UBits)1127743488L)
      msg = "not compiled with SWAPPED_DOUBLE";
#endif
    if (BAD_SAR)
      msg = "arithmetic right-shift broken";
    luaL_error(L, "bit library self-test failed (%s)", msg);
  }
#if LUA_VERSION_NUM < 502
  luaL_register(L, "bit", bit_funcs);
#else
  luaL_newlib(L, bit_funcs);
#endif
  return 1;
}`
]

export const INPUT = _INPUTS[0];

export const INPUTS = [
  // Función 1
  `int main() { 
    int a = 5; 
    int b = 3; 
    int suma = a + b; 
    printf("La suma de %d y %d es %d", a, b, suma); 
    return 0; 
  }`,
  // Función 2
  `int main() { 
    int num; 
    printf("Ingrese un número entero: "); 
    scanf("%d", &num); 
    if (num % 2 == 0) { 
      printf("%d es par", num); 
    } else { 
      printf("%d es impar", num); 
    } 
    return 0; 
  }`,
  // Función 3
  `int main() { 
    int i; 
    for (i = 1; i <= 10; i++) { 
      printf("%d", i); 
    } 
    return 0; 
  }`,
  // Función 4
  `int main() { 
    int opcion; 
    printf("1. Sumar 2. Restar 3. Multiplicar 4. Dividir Seleccione una opción: "); 
    scanf("%d", &opcion); 
    
    switch (opcion) { 
      case 1: 
        printf("Suma seleccionada"); 
        break; 
      case 2: 
        printf("Resta seleccionada"); 
        break; 
      case 3: 
        printf("Multiplicación seleccionada"); 
        break; 
      case 4: 
        printf("División seleccionada"); 
        break; 
      default: 
        printf("Opción no válida"); 
      } 

      return 0; 
    }`,
  // Función 5
  `int main() { 
    int n, i, fact = 1; 
    printf("Ingrese un número entero positivo: "); 
    scanf("%d", &n); 
    
    if (n < 0) 
      printf("Error: No se puede calcular el factorial de un número negativo"); 
    else { 
      for (i = 1; i <= n; ++i) { 
        fact *= i; 
      } 
      printf("El factorial de %d es %d", n, fact); 
    } 
    
    return 0; 
  }`,
  // Función 6
  `int main() { 
    int num, i, esPrimo = 1; 
    printf("Ingrese un número entero positivo: "); 
    scanf("%d", &num); 
    
    if (num <= 1) esPrimo = 0; 
    else { 
      for (i = 2; i <= num / 2; ++i) { 
        if (num % i == 0) { 
          esPrimo = 0; 
          break; 
        } 
      } 
    } 
    
    if (esPrimo) 
      printf("%d es primo", num); 
    else 
    printf("%d no es primo", num); 
  
    return 0; 
  }`,
  // Función 7
  `int main() { 
    int n, c = 0, k = 0, espacio = 1; 
    printf("Ingrese el número de filas en el triángulo de Pascal: "); 
    scanf("%d", &n); 
    
    for (c = 0; c < n; c++) { 
      for (k = 0; k < espacio; k++) 
        printf(" "); espacio++; 
      
      for (k = 0; k <= c; k++) { 
        if (k == 0 || c == 0) 
          printf("1 "); 
        else 
          printf("%d ", factorial(c) / (factorial(k) * factorial(c - k))); } printf(""); 
      } 
        
      return 0; 
    } 
      
      int factorial(int n) { 
        int c, fact = 1; 
        for (c = 1; c <= n; c++) 
          fact = fact * c; return fact; 
      }`,
  // Función 8
  `int main() { 
    int num, reverse = 0, temp; 
    printf("Ingrese un número entero: "); 
    scanf("%d", &num); 
    temp = num; 
    
    while (temp != 0) { 
      reverse = reverse * 10; 
      reverse = reverse + temp % 10; 
      temp = temp / 10; 
    } 
    
    if (num == reverse) 
      printf("%d es un palíndromo", num); 
    else 
      printf("%d no es un palíndromo", num); 
    
    return 0; 
  }`,
  // Función 9
  `int main() { int num, original, remainder, result = 0; printf("Ingrese un número entero: "); scanf("%d", &num); original = num; while (original != 0) { remainder = original % 10; result += remainder * remainder * remainder; original /= 10; } if (result == num) printf("%d es un número Armstrong", num); else printf("%d no es un número Armstrong", num); return 0; }`,
  // Función 10
  `int main() { int num, reversedNumber = 0, remainder; printf("Ingrese un número entero: "); scanf("%d", &num); while(num != 0) { remainder = num%10; reversedNumber = reversedNumber*10 + remainder; num /= 10; } printf("El número invertido es: %d", reversedNumber); return 0; }`,
  // Función 11
  `int main() { int num, sum = 0, i = 1; printf("Ingrese un número entero positivo: "); scanf("%d", &num); while (i <= num) { sum += i; ++i; } printf("La suma de los primeros %d números naturales es: %d", num, sum); return 0; }`,
  // Función 12
  `int main() { int num1, num2, gcd; printf("Ingrese dos enteros positivos: "); scanf("%d %d", &num1, &num2); gcd = findGCD(num1, num2); printf("El MCD de %d y %d es: %d", num1, num2, gcd); return 0; } int findGCD(int x, int y) { while (x != y) { if (x > y) { x -= y; } else { y -= x; } } return x; }`,
  // Función 13
  `int main() { int num1, num2; printf("Ingrese dos números: "); scanf("%d %d", &num1, &num2); printf("El MCM de %d y %d es: %d", num1, num2, findLCM(num1, num2)); return 0; } int findGCD(int x, int y) { while (x != y) { if (x > y) x -= y; else y -= x; } return x; } int findLCM(int x, int y) { return (x*y)/findGCD(x, y); }`,
  // Función 14
  `int main() { int c, n, fact = 1; printf("Ingrese un número para calcular su factorial: "); scanf("%d", &n); for (c = 1; c <= n; c++) fact *= c; printf("Factorial de %d = %d", n, fact); return 0; }`,
  // Función 15
  `int main() { int rows, i, j, number = 1; printf("Ingrese el número de filas: "); scanf("%d", &rows); for (i = 1; i <= rows; i++) { for (j = 1; j <= i; j++) { printf("%d ", number); ++number; } printf("\\n"); } return 0; }`,
  // Función 16
  `int main() { int rows, coef = 1, space, i, j; printf("Ingrese el número de filas: "); scanf("%d", &rows); for (i = 0; i < rows; i++) { for (space = 1; space <= rows - i; space++) printf("  "); for (j = 0; j <= i; j++) { if (j == 0 || i == 0) coef = 1; else coef = coef * (i - j + 1) / j; printf("%4d", coef); } printf("\\n"); } return 0; }`,
  // Función 17
  `int main() { int rows, i, j; printf("Ingrese el número de filas: "); scanf("%d", &rows); for (i = 1; i <= rows; i++) { for (j = 1; j <= i; j++) { printf("* "); } printf("\\n"); } return 0; }`,
  // Función 18
  `int main() { int num, reverse = 0; printf("Ingrese un número entero: "); scanf("%d", &num); while (num != 0) { reverse = reverse * 10; reverse = reverse + num % 10; num = num / 10; } printf("El número invertido es: %d", reverse); return 0; }`,
  // Función 19
  `int main() { int num1, num2, hcf; printf("Ingrese dos enteros positivos: "); scanf("%d %d", &num1, &num2); hcf = calculateHCF(num1, num2); printf("El MCD de %d y %d es: %d", num1, num2, hcf); return 0; } int calculateHCF(int x, int y) { if (y == 0) return x; else return calculateHCF(y, x % y); }`,
  // Función 20
  `int main() { int n, i, j; printf("Ingrese el número de filas: "); scanf("%d", &n); for (i = 1; i <= n; i++) { for (j = 1; j <= n - i; j++) { printf(" "); } for (j = 1; j <= i; j++) { printf("* "); } printf("\\n"); } return 0; }`
];
