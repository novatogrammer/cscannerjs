import { Constant } from './automata/Constant.mjs';
import { Variable } from './automata/Variable.mjs';

const c = new Constant();
const v = new Variable();

export class Token {

  constructor(value) {
    this.value = value;
    this.type = this.getType();
  }

  isRevervedWord(token) {
    const reservedWords = {
      'auto': 'AUTO',
      'double': 'DOUBLE',
      'int': 'INT',
      'float': 'FLOAT',
      'string': 'STR',
      'char': 'CHAR',
      'main': 'MAIN',
      'void': 'VOID',
      'break': 'BREAK',
      'do': 'DO',
      'else': 'ELSE',
      'if': 'IF',
      'while': 'WHILE',
      'return': 'RETURN',
      'scanf': 'READ',
      'printf': 'WRITE',
      'struct': 'STRUCT',
      'long': 'LONG',
      'switch': 'SWITCH',
      'case': 'CASE',
      'enum': 'ENUM',
      'register': 'REGISTER',
      'typedef': 'TYPE_DEF',
      'extern': 'EXTERN',
      'union': 'UNION',
      'const': 'CONST',
      'short': 'SHORT',
      'unsigned': 'UNSIGNED',
      'continue': 'CONTINUE',
      'for': 'FOR',
      'signed': 'SIGNED',
      'default': 'DEFAULT',
      'include': 'INCLUDE',
      'goto': 'GO_TO',
      'sizeof': 'SIZE_OF',
      'volatile': 'VOLATILE',
      'static': 'STATIC'      
    }

    return reservedWords[token] || false;
  }

  isSpecialSimbol(token) {
    const specialSimbols = {
      '': 'WHITE_SPACE',
      '{': 'LBRACE',
      '}': 'RBRACE',
      '[': 'LSQUARE',
      ']': 'RSQUARE',
      '(': 'LPAR',
      ')': 'RPAR',
      ';': 'SEMI',
      '+': 'PLUS',
      '-': 'MINUS',
      '*': 'MUL_OP',
      '/': 'DIV_OP',
      '&': 'AND_OP',
      '|': 'OR_OP',
      '!': 'NOT_OP',
      '=': 'ASSIGN',
      '<': 'LT',
      '>': 'GT',
      '<<': 'SHL_OP',
      '>>': 'SHR_OP',
      '==': 'EQ',
      '!=': 'NOTEQ',
      '<=': 'LTEQ',
      '>=': 'GTEQ',
      '&&': 'ANDAND',
      '||': 'OROR',
      '//': 'LINE_COMMENT',
      ',': 'COMMA',
      '"': 'QUOT',
      '\'': 'QUOT_S',
      '>>=': 'TRIPLE_SHR_OP',
      '<<=': 'TRIPLE_SHL_OP',
      '->': 'ARROW',
      '++': 'INCREMENT',
      '--': 'DECREMENT',
      '+=': 'PLUS_ASSIGN',
      '-=': 'MINUS_ASSIGN',
      '*=': 'MUL_ASSIGN',
      '/=': 'DIV_ASSIGN',
      '%=': 'MOD_ASSIGN',
      '&=': 'AND_ASSIGN',
      '|=': 'OR_ASSIGN',
      '^=': 'XOR_ASSIGN',
      '.': 'DOT',
      ':': 'COLON',
      '#': 'HASH',
      '~': 'TILDE',
      '%': 'MOD',
      '?': 'QUESTION_MARK'
    };
    return specialSimbols[token] || false;
  }

  isEscape(token) {
    const escape = {
      '\n': 'END_LINE',
      '\t': 'H_TAB',
      '\0': 'END_TEXT'
    }
    return escape[token] || false;
  }

  isConstant(token) {
    return c.isConstant(token) ? token.toLowerCase().includes('e') ? 'CONSTANT' : 'INT_NUM' : false;
  }

  isID(token) {
    return v.isVariable(token) ? 'ID' : false;
  }

  isString(token) {
    return (['"', "'"].indexOf(token[0]) != -1 && ['"', "'"].indexOf(token[token.length - 1]) != -1) ? 'STRING' : false;
  }

  getValue() {
    return this.value;
  }

  getType() {
    return this.isEscape(this.value) || this.isRevervedWord(this.value) || this.isSpecialSimbol(this.value) || this.isConstant(this.value) || this.isID(this.value) || this.isString(this.value) || 'ERROR';
  }

}