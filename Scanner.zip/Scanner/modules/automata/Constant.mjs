import { Automata } from './Automata.mjs';

export class Constant extends Automata {

  constructor() {
    const statesNames = [
      "INI",  // Estado inicial
      "SAI",  // Estado de Signo al inicio
      "DIG",  // Estado de Dígito
      "PIS",  // Estado de Punto al inicio o después de Signo
      "EXP",  // Estado de Símbolo de exponente
      "PDD",  // Estado de Punto después de Dígito
      "DDP",  // Estado de Dígito después de Punto
      "SDE",  // Estado de Signo después de Exponencial
      "DDE",  // Estado de Dígito después de Exponencial
      "ERROR" // Estado de Error
    ];
    const transitionsNames = [
      ["SAI", "DIG", "ERROR", "PIS"], // INI
      ["ERROR", "DIG", "ERROR", "PIS"], // SAI
      ["ERROR", "DIG", "EXP", "PDD"], // DIG
      ["ERROR", "DDP", "ERROR", "ERROR"], // PIS
      ["SDE", "DDE", "ERROR", "ERROR"], // EXP
      ["ERROR", "DIG", "EXP", "ERROR"], // PDD
      ["ERROR", "DDP", "EXP", "ERROR"], // DDP
      ["ERROR", "DDE", "ERROR", "ERROR"], // SDE
      ["ERROR", "DDE", "ERROR", "ERROR"], // DDE
      ["ERROR", "ERROR", "ERROR", "ERROR"] // ERROR
    ];
    super(statesNames, ["DIG", "DDP", "DDE"], transitionsNames);
  }

  nextState(state, char) {
    if (char === '+' || char === '-') {
      return super.getTransitions()[state][0];
    }
    else if (!isNaN(parseInt(char))) {
      return super.getTransitions()[state][1];
    }
    else if (char.toLowerCase() === 'e') {
      return super.getTransitions()[state][2];
    }
    else if (char === '.') {
      return super.getTransitions()[state][3];
    }
    else {
      return super.getStates()["ERROR"];
    }
  }

  isConstant(string) {
    let state = super.getStates()["INI"];
    for (let i = 0; i < string.length; i++) {
      state = this.nextState(state, string[i]);
      if (state === super.getStates()["ERROR"]) {
        return false;
      }
    }
    return this.isAccepted(state);
  }

}