import { Automata } from './Automata.mjs';

export class Variable extends Automata {

  constructor() {
    const statesNames = [
      "INI",  // Estado inicial
      "EAN",  // Estado Alfanumérico con Caracteres Especiales
      "ERROR" // Estado de Error
    ];
    const transitionsNames = [
      ["EAN", "ERROR", "EAN"], // INI
      ["EAN", "EAN", "EAN"], // EAN
      ["EAN", "EAN", "EAN"] // ERROR
    ];
    super(statesNames, ["EAN"], transitionsNames);
  }

  isAlpha(char) {
    let ascii = char.toUpperCase().charCodeAt(0);
    return ascii > 64 && ascii < 91;
  };

  nextState(state, char) {
    if (this.isAlpha(char) && char !== "_" && char !== "$")
      return super.getTransitions()[state][0];
    else if (!isNaN(char))
      return super.getTransitions()[state][1];
    else if (char === "_" || char === "$")
      return super.getTransitions()[state][2];
    else {
      return super.getStates()["ERROR"];
    }
  }

  isVariable(string) {
    let state = super.getStates()["INI"];
    for (let i = 0; i < string.length; i++) {
      state = this.nextState(state, string[i]);
      if (state === super.getStates()["ERROR"]) {
        return false;
      }
    }
    return this.isAccepted(state);
  }

}