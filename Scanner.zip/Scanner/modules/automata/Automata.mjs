export class Automata {

  constructor(states, acceptanceStates, transitions) {
    this.states = {};
    this.setStates(states);
    this.acceptanceStates = [];
    this.setAcceptanceStates(states, acceptanceStates);
    this.transitions = [];
    this.setTransitions(transitions);
  }

  isAccepted(state) {
    return this.acceptanceStates.indexOf(state) != -1;;
  }

  getStates() {
    return this.states;
  }

  setStates(states) {
    states.forEach((state, index) => {
      this.states[state] = index;
    });
  }

  getAcceptanceStates() {
    return this.acceptanceStates;
  }

  setAcceptanceStates(states, acceptanceStates) {
    states.forEach((state, index) => {
      acceptanceStates.forEach((acceptanceState) => {
        if (state == acceptanceState) {
          this.acceptanceStates.push(index);
        }
      });
    });
  }

  getTransitions() {
    return this.transitions;
  }

  setTransitions(transitions) {
    transitions.forEach((row, index) => {
      this.transitions.push([]);
      row.forEach((transition) => {
        this.transitions[index].push(this.states[transition]);
      });
    });
  }

}