export const substring = (string, start, end) => {
  let substring = '';
  for (let i = start; i <= end; i++) {
    substring += string[i];
  }
  return substring;
}

export const trim = (string) => {
  let start = 0;
  let end = string.length - 1;
  while (start < string.length && string[start] === ' ') {
    start++;
  }
  while (end >= 0 && string[end] === ' ') {
    end--;
  }
  return substring(string, start, end);
}

export const split = (string, separator, include = false) => {
  const array = [];
  let section = "";
  for (let i = 0; i < string.length; i++) {
    if (string[i] === separator) {
      if(section != "") {
        array.push(section);
      }
      include ? array.push(separator) : undefined;
      section = "";
    }
    else {
      section += string[i];
    }
  }
  if(section != "") {
    array.push(section);
  }
  return array;
}

export const matched = (string, separators, spaces) => {
  var parts = [];
  var currentPart = '';
  
  for (var i = 0; i < string.length; i++) {
    if (separators.indexOf(string[i]) !== -1) {
      parts.push(currentPart);
      parts.push(string[i]);
      currentPart = '';
    } else {
      currentPart += string[i];
    }
  }
  
  if (!spaces) {
    if(currentPart != '') {
      parts.push(currentPart);
    }
  }
  else {
    if(separators.indexOf(string) == -1) {
      parts.push(currentPart);
    }
  }
  
  return parts;
}

export function tabular(vectores) {
  const resultado = [];
  let contadorBlancos = 0;

  for (let i = 0; i < vectores.length; i++) {
      const vectorActual = vectores[i];

      if (vectorActual.length === 0 || (vectorActual.length === 1 && vectorActual[0] === "")) {
          contadorBlancos++;
          if (contadorBlancos === 2) {
              resultado.push(["\t"]);
              contadorBlancos = 0;
          }
      } else {
          resultado.push(vectorActual);
          contadorBlancos = 0;
      }
  }

  return resultado;
}