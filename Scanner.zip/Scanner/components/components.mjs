import { Spinner } from './Spinner/Spinner.mjs';
import { Button } from './Button/Button.mjs';
import { Input } from './Input/Input.mjs';
import { Loader } from './Loader/Loader.mjs';

customElements.define('lx-spinner', Spinner);
customElements.define('lx-button', Button);
customElements.define('lx-input', Input);
customElements.define('lx-loader', Loader);