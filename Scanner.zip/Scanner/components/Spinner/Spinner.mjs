import {Tokens} from '../tokens.mjs';

const tokens = Tokens.light;

export class Spinner extends HTMLElement {

    constructor() {
        super();
        this.attachShadow({ mode: 'open' });
        this.properties = {
            color: ['accent', 'black', 'white', 'gray', 'success', 'warning', 'danger'],
            size: ['xs', 's', 'm', 'l', 'xl', 'xxl', 'xxxl']
        }
        this.color = this.getAttribute('color');
        this.size = this.getAttribute('size');
    }

    static get observedAttributes() {
        return ['color'];
    }

    connectedCallback() {
        this.render();
    }

    render() {
        const color = this.getProperty('color', 'light');
        const size = this.getProperty('size', 'm');
        const style = `
        <style>
            :host {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
                outline: none;
                border: none;
                --lx-spinner-color-accent: ${tokens['--lx-color-solid-accent']};
                --lx-spinner-color-black: ${tokens['--lx-color-solid-black']};
                --lx-spinner-color-white: ${tokens['--lx-color-solid-white']};
                --lx-spinner-color-gray: ${tokens['--lx-color-solid-gray']};
                --lx-spinner-color-success: ${tokens['--lx-color-solid-success']};
                --lx-spinner-color-warning: ${tokens['--lx-color-solid-warning']};
                --lx-spinner-color-danger: ${tokens['--lx-color-solid-danger']};
                --lx-spinner-size-xs: 10px;
                --lx-spinner-size-s: 15px;
                --lx-spinner-size-m: 20px;
                --lx-spinner-size-l: 25px;
                --lx-spinner-size-xl: 30px;
                --lx-spinner-size-xxl: 35px;
                --lx-spinner-size-xxxl: 40px;
            }

            .lx-spinner {
                width: var(--lx-spinner-size-${size});
                height: var(--lx-spinner-size-${size});
                aspect-ratio: 1;
                border-radius: 50%;
                background: radial-gradient(farthest-side, var(--lx-spinner-color-${color}) 100%, #0000) top/3px 3px no-repeat, conic-gradient(#0000 30%, var(--lx-spinner-color-${color}));
                mask: radial-gradient(farthest-side, #0000 calc(100% - 3px), #000 0);
                -webkit-mask: radial-gradient(farthest-side, #0000 calc(100% - 3px), #000 0);
                animation: lx-spin 1s infinite linear;
                will-change: transform;
            }
        
            @keyframes lx-spin {
                100%{transform: rotate(1turn)}
            }
        </style>
      `;

      this.shadowRoot.innerHTML = style;

      const spinner = document.createElement('div');
      spinner.classList.add('lx-spinner');
      this.shadowRoot.appendChild(spinner);
    }

    attributeChangedCallback(name, oldValue, newValue) {
        if (oldValue !== newValue) {
          this.render();
        }
      }

    getProperty(propertyName, defaultValue) {
        return (this[propertyName] && this.properties[propertyName].includes(this[propertyName])) ? this[propertyName] : defaultValue;
    }

}

export default Spinner;