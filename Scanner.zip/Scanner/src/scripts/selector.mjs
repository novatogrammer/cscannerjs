const $ = selector => document.querySelector(selector);
export default $;