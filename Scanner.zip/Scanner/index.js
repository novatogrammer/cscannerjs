import { INPUT } from "./modules/constants/constants.mjs";
import { Scanner } from "./modules/Scanner.mjs";

const scanner = new Scanner({
  line: "\n",
  separator: " ",
});

const tokens = scanner.read(INPUT).getTokens();

console.log(scanner);

tokens.forEach((token) => {
  console.log(`Token: ${token.getType()} "${token.getValue()}"`);
});