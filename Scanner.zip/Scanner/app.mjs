import { INPUT, INPUTS } from './modules/constants/constants.mjs';
import { Scanner } from './modules/Scanner.mjs';
import $ from './src/scripts/selector.mjs';

var isAnimated = false;
var isSpaces = true;
var fileName = "test.txt";
var input = INPUT;

const $content = $('#content');
const $console = $('#console');

document.addEventListener('DOMContentLoaded', async () => {
    $('#loader').load(false);
    await scan(input);
});

const delay = async (delay) => {
    if (isAnimated) {
        await new Promise((resolve) =>
            setTimeout(() => {
                resolve();
            }, delay)
        );
    }
}

const scroll = () => {
    if (isAnimated) {
        window.scroll({
            top: 2500,
            left: 0,
            behavior: 'smooth'
        });
        $('#indicator').scrollIntoView({
            behavior: 'smooth'
        });
    }
}

$('#write').whenClick(() => {
    $('#modal').classList.add('active');
    $('#code').value = input;
    $('#code').focus();
    $('#fileName').innerText = "test.txt";
});

$('#addCode').whenClick(() => {
    $('#modal').classList.remove('active');
    input = $('#code').value;
    $('#code').value = "";
    $('#animate').click();
});

$('#dropCode').whenClick(() => {
    $('#code').value = "";
    $('#modal').classList.remove('active');
});

$('#import').whenClick(async () => {
    $('#importCode').click();
});

$('#generate').whenClick(async () => {
    isAnimated = true;
    $('#generateLoader').setAttribute('disabled', 'false');
    input = INPUTS[Math.floor(Math.random() * INPUTS.length)];
    $('#write').click();
    await delay(1000);
    isAnimated = false;
    $('#generateLoader').setAttribute('disabled', 'true');
    $('#fileName').innerText = "generated.text";
});

$('#animate').whenClick(async () => {
    $('#write').setAttribute('disabled', 'true');
    $('#import').setAttribute('disabled', 'true');
    $('#generate').setAttribute('disabled', 'true');
    $('body').classList.add('lx-body-animated');
    $('#fileName').classList.add('lx-file-running');
    isAnimated = true;
    await scan(input);
    $('#fileName').classList.remove('lx-file-running');
    $('body').classList.remove('lx-body-animated');
    $('#write').setAttribute('disabled', 'false');
    $('#import').setAttribute('disabled', 'false');
    $('#generate').setAttribute('disabled', 'false');
})

$('#fileName').addEventListener('click', () => {
    isSpaces = !isSpaces;
    alert("Scanner V" + (isSpaces ? "1" : "2"));
});

$('#animateChange').whenClick(() => {
    isAnimated = !isAnimated;
});

async function scan(input) {
    $content.innerHTML = "";
    $console.innerHTML = "";

    const scanner = new Scanner({
        line: '\n',
        separator: ' ',
        spaces: isSpaces
    });

    const tokens = scanner.read(input).getTokens();

    console.log(scanner);

    const lines = [[]];
    tokens.forEach((token) => {
        lines[lines.length - 1].push(token);
        if (token.value === '\n') {
            lines.push([]);
        }
    });

    await editorRender(lines);

    $('#loader').load(false);

    await delay(500);

    await consoleRender(tokens);
}

async function editorRender(lines) {
    lines.forEach((line, i) => {
        const $line = document.createElement('div');
        $line.classList.add('lx-line');
        line.forEach((token) => {
            $line.innerHTML += `<div class='lx-token ${token.type}'>${token.value}<span class='lx-token-type'>${token.type}</span></div>`;
        });
        const $codeLine = document.createElement('div');
        $codeLine.classList.add('lx-code-line');
        $codeLine.innerHTML = `<div class='lx-code-line-number'>${i + 1}</div>`;
        $codeLine.appendChild($line);
        $content.appendChild($codeLine);
    });
}

async function consoleRender(tokens) {
    $console.innerHTML += `<p style='color: green;'>
    [*] Inicializaando escaneo de entrada test.txt 
    -- <b>Clex-JS</b>
    </p>`;

    await delay(500);

    $console.innerHTML += `<br>
    <p style='color: lightgreen;'>
    Procesando...
    </p>
    <br>`;

    await delay(2000);

    for (let i = 0; i < tokens.length; i++) {
        const token = tokens[i];
        if (token.type != 'WHITE_SPACE') {
            $console.innerHTML += `<p  class=' ${token.getType()}'>
            [${i + 1}] Token: ${token.getType()} → ${token.getValue()}
            </p>`;
            scroll();
            await delay(100);
        }
    }

    await delay(500);

    $console.innerHTML += `<br>
    <p style='color: gold;'>
    [!] Tokens generados con éxito.
    </p>`;
    scroll();

    await delay(500);

    $console.innerHTML += `<br>
    <p style='color: red;'>
    [X] Fin del procesamiento 
    <b>Clex-JS</b> 
    @mapallares
    </p>`;

    isAnimated = false;
}

$('#importCode').addEventListener('change', readFile, false);

function readFile(e) {
    var archivo = e.target.files[0];
    if (!archivo) {
        return;
    }
    var lector = new FileReader();
    lector.onload = function (e) {
        var contenido = e.target.result;
        input = contenido;
        $('#animate').click();
    };
    lector.readAsText(archivo);
    fileName = e.target.files[0].name;
    $('#fileName').innerText = fileName;
}